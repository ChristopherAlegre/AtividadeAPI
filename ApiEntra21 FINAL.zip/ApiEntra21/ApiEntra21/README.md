# ApiEntra21 - Endpoints GET/POST/PUT/DELETE (Memória)

## Como rodar
1. Abra `ApiEntra21.sln` no Visual Studio 2022+.
2. Defina o projeto **ApiEntra21** como Startup.
3. Restaure os pacotes (Swashbuckle).
4. Rode (F5). O Swagger abrirá em `/swagger`.

## Endpoints
- `GET /api/produto` — lista produtos
- `GET /api/produto/{id}` — busca produto
- `POST /api/produto` — adiciona (JSON: `{ "nome": "Item", "preco": 99.9 }`)
- `PUT /api/produto/{id}` — atualiza (JSON idem)
- `DELETE /api/produto/{id}` — remove

## Observação
Implementação simples em memória, seguindo a arquitetura: Api → Application → Domain → Infra.
