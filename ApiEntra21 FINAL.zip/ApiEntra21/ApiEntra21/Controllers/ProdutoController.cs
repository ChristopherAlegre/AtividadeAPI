using Microsoft.AspNetCore.Mvc;
using Modelo.Application.Services;
using Modelo.Domain.Entities;

namespace ApiEntra21.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProdutoController : ControllerBase
    {
        private readonly ProdutoService _service;

        public ProdutoController(ProdutoService service)
        {
            _service = service;
        }

        // GET api/produto
        [HttpGet]
        public IActionResult Get() => Ok(_service.ListarTodos());

        // GET api/produto/5
        [HttpGet("{id:int}")]
        public IActionResult Get(int id)
        {
            var produto = _service.BuscarPorId(id);
            if (produto == null)
                return NotFound();
            return Ok(produto);
        }

        // POST api/produto
        [HttpPost]
        public IActionResult Post([FromBody] Produto produto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            _service.Adicionar(produto);
            return CreatedAtAction(nameof(Get), new { id = produto.Id }, produto);
        }

        // PUT api/produto/5
        [HttpPut("{id:int}")]
        public IActionResult Put(int id, [FromBody] Produto produto)
        {
            var existente = _service.BuscarPorId(id);
            if (existente == null) return NotFound();

            produto.Id = id;
            _service.Atualizar(produto);
            return NoContent();
        }

        // DELETE api/produto/5
        [HttpDelete("{id:int}")]
        public IActionResult Delete(int id)
        {
            var existente = _service.BuscarPorId(id);
            if (existente == null) return NotFound();

            _service.Deletar(id);
            return NoContent();
        }
    }
}
