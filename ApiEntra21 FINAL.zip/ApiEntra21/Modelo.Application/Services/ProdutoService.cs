using Modelo.Domain.Entities;
using Modelo.Domain.Interfaces;
using System.Collections.Generic;

namespace Modelo.Application.Services
{
    public class ProdutoService
    {
        private readonly IProdutoRepository _repository;

        public ProdutoService(IProdutoRepository repository)
        {
            _repository = repository;
        }

        public List<Produto> ListarTodos() => _repository.GetAll();

        public Produto? BuscarPorId(int id) => _repository.GetById(id);

        public void Adicionar(Produto produto) => _repository.Add(produto);

        public void Atualizar(Produto produto) => _repository.Update(produto);

        public void Deletar(int id) => _repository.Delete(id);
    }
}
