using Modelo.Domain.Entities;
using Modelo.Domain.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace Modelo.Infra.Repositories
{
    public class ProdutoRepository : IProdutoRepository
    {
        private static readonly List<Produto> _produtos = new()
        {
            new Produto { Id = 1, Nome = "Notebook", Preco = 3500m },
            new Produto { Id = 2, Nome = "Mouse", Preco = 80m }
        };

        public List<Produto> GetAll() => _produtos.ToList();

        public Produto? GetById(int id) => _produtos.FirstOrDefault(p => p.Id == id);

        public void Add(Produto produto)
        {
            produto.Id = _produtos.Any() ? _produtos.Max(p => p.Id) + 1 : 1;
            _produtos.Add(produto);
        }

        public void Update(Produto produto)
        {
            var existente = GetById(produto.Id);
            if (existente != null)
            {
                existente.Nome = produto.Nome;
                existente.Preco = produto.Preco;
            }
        }

        public void Delete(int id)
        {
            var item = GetById(id);
            if (item != null) _produtos.Remove(item);
        }
    }
}
