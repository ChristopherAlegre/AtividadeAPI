using Modelo.Domain.Entities;
using System.Collections.Generic;

namespace Modelo.Domain.Interfaces
{
    public interface IProdutoRepository
    {
        List<Produto> GetAll();
        Produto? GetById(int id);
        void Add(Produto produto);
        void Update(Produto produto);
        void Delete(int id);
    }
}
